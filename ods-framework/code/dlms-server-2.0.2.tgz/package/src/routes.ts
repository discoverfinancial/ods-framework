/* tslint:disable */
/* eslint-disable */
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import type { TsoaRoute } from '@tsoa/runtime';
import {  fetchMiddlewares, ExpressTemplateService } from '@tsoa/runtime';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { UserGroupController } from './controllers/userGroupController';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { AdminController } from './controllers/adminController';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { AttachmentGroupController } from './controllers/attachmentGroupController';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { DocController } from './controllers/docController';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { IteratorController } from './controllers/docController';
// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
import { ActionController } from './controllers/actionController';
import type { Request as ExRequest, Response as ExResponse, RequestHandler, Router } from 'express';
const multer = require('multer');




// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

const models: TsoaRoute.Models = {
    "Person": {
        "dataType": "refObject",
        "properties": {
            "name": {"dataType":"string","required":true},
            "department": {"dataType":"string","required":true},
            "email": {"dataType":"string","required":true},
            "title": {"dataType":"string","required":true},
            "employeeNumber": {"dataType":"string","required":true},
        },
        "additionalProperties": {"dataType":"any"},
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "UserGroupInfo": {
        "dataType": "refObject",
        "properties": {
            "id": {"dataType":"string","required":true},
            "members": {"dataType":"array","array":{"dataType":"refObject","ref":"Person"},"required":true},
            "deletable": {"dataType":"boolean","required":true},
        },
        "additionalProperties": {"dataType":"any"},
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "UserGroupList": {
        "dataType": "refObject",
        "properties": {
            "count": {"dataType":"double","required":true},
            "items": {"dataType":"array","array":{"dataType":"refObject","ref":"UserGroupInfo"},"required":true},
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "UserGroupCreate": {
        "dataType": "refObject",
        "properties": {
            "id": {"dataType":"string","required":true},
            "members": {"dataType":"array","array":{"dataType":"refObject","ref":"Person"}},
            "deletable": {"dataType":"boolean"},
        },
        "additionalProperties": {"dataType":"any"},
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "UserGroupUpdate": {
        "dataType": "refObject",
        "properties": {
            "members": {"dataType":"array","array":{"dataType":"refObject","ref":"Person"}},
        },
        "additionalProperties": {"dataType":"any"},
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "PostDocs": {
        "dataType": "refObject",
        "properties": {
            "stream": {"dataType":"string"},
            "params": {"dataType":"nestedObjectLiteral","nestedProperties":{"projection":{"dataType":"any"},"options":{"dataType":"nestedObjectLiteral","nestedProperties":{"limit":{"dataType":"double"},"projection":{"dataType":"any"},"sort":{"dataType":"any"}}},"match":{"dataType":"any"}}},
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "CommentCreate": {
        "dataType": "refObject",
        "properties": {
            "topic": {"dataType":"string","required":true},
            "text": {"dataType":"string","required":true},
            "private": {"dataType":"boolean"},
            "approved": {"dataType":"string"},
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "CommentHistory": {
        "dataType": "refObject",
        "properties": {
            "date": {"dataType":"double","required":true},
            "user": {"ref":"Person","required":true},
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "CommentInfo": {
        "dataType": "refObject",
        "properties": {
            "id": {"dataType":"string","required":true},
            "date": {"dataType":"double","required":true},
            "user": {"ref":"Person","required":true},
            "topic": {"dataType":"string","required":true},
            "text": {"dataType":"string","required":true},
            "edited": {"dataType":"array","array":{"dataType":"refObject","ref":"CommentHistory"}},
            "approved": {"dataType":"string"},
            "private": {"dataType":"boolean"},
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
    "CommentUpdate": {
        "dataType": "refObject",
        "properties": {
            "topic": {"dataType":"string"},
            "text": {"dataType":"string"},
            "private": {"dataType":"boolean"},
            "approved": {"dataType":"string"},
        },
        "additionalProperties": false,
    },
    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
};
const templateService = new ExpressTemplateService(models, {"noImplicitAdditionalProperties":"throw-on-extras","bodyCoercion":true});

// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa




export function RegisterRoutes(app: Router,opts?:{multer?:ReturnType<typeof multer>}) {

    // ###########################################################################################################
    //  NOTE: If you do not see routes for all of your controllers in this file, then you might not have informed tsoa of where to look
    //      Please look into the "controllerPathGlobs" config option described in the readme: https://github.com/lukeautry/tsoa
    // ###########################################################################################################

    const upload = opts?.multer ||  multer({"limits":{"fileSize":8388608}});

    
        const argsUserGroupController_getUserGroups: Record<string, TsoaRoute.ParameterSchema> = {
        };
        app.get('/api/user_groups',
            ...(fetchMiddlewares<RequestHandler>(UserGroupController)),
            ...(fetchMiddlewares<RequestHandler>(UserGroupController.prototype.getUserGroups)),

            async function UserGroupController_getUserGroups(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserGroupController_getUserGroups, request, response });

                const controller = new UserGroupController();

              await templateService.apiHandler({
                methodName: 'getUserGroups',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsUserGroupController_getUserGroup: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
        };
        app.get('/api/user_groups/:id',
            ...(fetchMiddlewares<RequestHandler>(UserGroupController)),
            ...(fetchMiddlewares<RequestHandler>(UserGroupController.prototype.getUserGroup)),

            async function UserGroupController_getUserGroup(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserGroupController_getUserGroup, request, response });

                const controller = new UserGroupController();

              await templateService.apiHandler({
                methodName: 'getUserGroup',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsUserGroupController_createUserGroup: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                body: {"in":"body","name":"body","required":true,"ref":"UserGroupCreate"},
        };
        app.put('/api/user_groups',
            ...(fetchMiddlewares<RequestHandler>(UserGroupController)),
            ...(fetchMiddlewares<RequestHandler>(UserGroupController.prototype.createUserGroup)),

            async function UserGroupController_createUserGroup(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserGroupController_createUserGroup, request, response });

                const controller = new UserGroupController();

              await templateService.apiHandler({
                methodName: 'createUserGroup',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsUserGroupController_updateUserGroup: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                args: {"in":"body","name":"args","required":true,"ref":"UserGroupUpdate"},
        };
        app.patch('/api/user_groups/:id',
            ...(fetchMiddlewares<RequestHandler>(UserGroupController)),
            ...(fetchMiddlewares<RequestHandler>(UserGroupController.prototype.updateUserGroup)),

            async function UserGroupController_updateUserGroup(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserGroupController_updateUserGroup, request, response });

                const controller = new UserGroupController();

              await templateService.apiHandler({
                methodName: 'updateUserGroup',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsUserGroupController_deleteUserGroup: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
        };
        app.delete('/api/user_groups/:id',
            ...(fetchMiddlewares<RequestHandler>(UserGroupController)),
            ...(fetchMiddlewares<RequestHandler>(UserGroupController.prototype.deleteUserGroup)),

            async function UserGroupController_deleteUserGroup(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsUserGroupController_deleteUserGroup, request, response });

                const controller = new UserGroupController();

              await templateService.apiHandler({
                methodName: 'deleteUserGroup',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAdminController_export: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
        };
        app.get('/api/admin/export',
            ...(fetchMiddlewares<RequestHandler>(AdminController)),
            ...(fetchMiddlewares<RequestHandler>(AdminController.prototype.export)),

            async function AdminController_export(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAdminController_export, request, response });

                const controller = new AdminController();

              await templateService.apiHandler({
                methodName: 'export',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAdminController_exportIds: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
        };
        app.get('/api/admin/export_ids',
            ...(fetchMiddlewares<RequestHandler>(AdminController)),
            ...(fetchMiddlewares<RequestHandler>(AdminController.prototype.exportIds)),

            async function AdminController_exportIds(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAdminController_exportIds, request, response });

                const controller = new AdminController();

              await templateService.apiHandler({
                methodName: 'exportIds',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAdminController_exportId: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                collection: {"in":"path","name":"collection","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
        };
        app.get('/api/admin/export/:collection/:id',
            ...(fetchMiddlewares<RequestHandler>(AdminController)),
            ...(fetchMiddlewares<RequestHandler>(AdminController.prototype.exportId)),

            async function AdminController_exportId(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAdminController_exportId, request, response });

                const controller = new AdminController();

              await templateService.apiHandler({
                methodName: 'exportId',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAdminController_importId: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                collection: {"in":"path","name":"collection","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                body: {"in":"body","name":"body","required":true,"dataType":"any"},
        };
        app.put('/api/admin/import/:collection/:id',
            ...(fetchMiddlewares<RequestHandler>(AdminController)),
            ...(fetchMiddlewares<RequestHandler>(AdminController.prototype.importId)),

            async function AdminController_importId(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAdminController_importId, request, response });

                const controller = new AdminController();

              await templateService.apiHandler({
                methodName: 'importId',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAdminController_import: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                body: {"in":"body","name":"body","required":true,"dataType":"any"},
        };
        app.post('/api/admin/import',
            ...(fetchMiddlewares<RequestHandler>(AdminController)),
            ...(fetchMiddlewares<RequestHandler>(AdminController.prototype.import)),

            async function AdminController_import(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAdminController_import, request, response });

                const controller = new AdminController();

              await templateService.apiHandler({
                methodName: 'import',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAdminController_reset: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                simpleInit: {"default":false,"in":"query","name":"simpleInit","dataType":"boolean"},
        };
        app.get('/api/admin/reset',
            ...(fetchMiddlewares<RequestHandler>(AdminController)),
            ...(fetchMiddlewares<RequestHandler>(AdminController.prototype.reset)),

            async function AdminController_reset(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAdminController_reset, request, response });

                const controller = new AdminController();

              await templateService.apiHandler({
                methodName: 'reset',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAttachmentGroupController_getAttachments: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
        };
        app.get('/api/docs/attachments',
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController)),
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController.prototype.getAttachments)),

            async function AttachmentGroupController_getAttachments(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAttachmentGroupController_getAttachments, request, response });

                const controller = new AttachmentGroupController();

              await templateService.apiHandler({
                methodName: 'getAttachments',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAttachmentGroupController_getDocAttachments: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                collection: {"in":"path","name":"collection","required":true,"dataType":"string"},
                docId: {"in":"path","name":"docId","required":true,"dataType":"string"},
        };
        app.get('/api/docs/:collection/:docId/attachments',
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController)),
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController.prototype.getDocAttachments)),

            async function AttachmentGroupController_getDocAttachments(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAttachmentGroupController_getDocAttachments, request, response });

                const controller = new AttachmentGroupController();

              await templateService.apiHandler({
                methodName: 'getDocAttachments',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAttachmentGroupController_getDocAttachment: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                collection: {"in":"path","name":"collection","required":true,"dataType":"string"},
                docId: {"in":"path","name":"docId","required":true,"dataType":"string"},
                attachmentId: {"in":"path","name":"attachmentId","required":true,"dataType":"string"},
        };
        app.get('/api/docs/:collection/:docId/attachments/:attachmentId',
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController)),
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController.prototype.getDocAttachment)),

            async function AttachmentGroupController_getDocAttachment(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAttachmentGroupController_getDocAttachment, request, response });

                const controller = new AttachmentGroupController();

              await templateService.apiHandler({
                methodName: 'getDocAttachment',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAttachmentGroupController_deleteDocAttachments: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                collection: {"in":"path","name":"collection","required":true,"dataType":"string"},
                docId: {"in":"path","name":"docId","required":true,"dataType":"string"},
                attachmentId: {"in":"path","name":"attachmentId","required":true,"dataType":"string"},
        };
        app.delete('/api/docs/:collection/:docId/attachments/:attachmentId',
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController)),
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController.prototype.deleteDocAttachments)),

            async function AttachmentGroupController_deleteDocAttachments(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAttachmentGroupController_deleteDocAttachments, request, response });

                const controller = new AttachmentGroupController();

              await templateService.apiHandler({
                methodName: 'deleteDocAttachments',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsAttachmentGroupController_createDocAttachments: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                collection: {"in":"path","name":"collection","required":true,"dataType":"string"},
                docId: {"in":"path","name":"docId","required":true,"dataType":"string"},
                file: {"in":"formData","name":"file","required":true,"dataType":"file"},
        };
        app.put('/api/docs/:collection/:docId/attachments',
            upload.fields([
                {
                    name: "file",
                    maxCount: 1
                }
            ]),
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController)),
            ...(fetchMiddlewares<RequestHandler>(AttachmentGroupController.prototype.createDocAttachments)),

            async function AttachmentGroupController_createDocAttachments(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsAttachmentGroupController_createDocAttachments, request, response });

                const controller = new AttachmentGroupController();

              await templateService.apiHandler({
                methodName: 'createDocAttachments',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_createDoc: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                body: {"in":"body","name":"body","required":true,"dataType":"any"},
        };
        app.put('/api/docs/:type',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.createDoc)),

            async function DocController_createDoc(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_createDoc, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'createDoc',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_createDocById: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                body: {"in":"body","name":"body","required":true,"dataType":"any"},
        };
        app.put('/api/docs/:type/:id',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.createDocById)),

            async function DocController_createDocById(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_createDocById, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'createDocById',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_postDocs: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                body: {"in":"body","name":"body","required":true,"ref":"PostDocs"},
        };
        app.post('/api/docs/:type',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.postDocs)),

            async function DocController_postDocs(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_postDocs, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'postDocs',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_getDocs: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                match: {"in":"query","name":"match","dataType":"string"},
                options: {"in":"query","name":"options","dataType":"string"},
                stream: {"in":"query","name":"stream","dataType":"string"},
        };
        app.get('/api/docs/:type',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.getDocs)),

            async function DocController_getDocs(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_getDocs, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'getDocs',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_getDoc: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
        };
        app.get('/api/docs/:type/:id',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.getDoc)),

            async function DocController_getDoc(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_getDoc, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'getDoc',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_updateDoc: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                args: {"in":"body","name":"args","required":true,"dataType":"any"},
        };
        app.patch('/api/docs/:type/:id',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.updateDoc)),

            async function DocController_updateDoc(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_updateDoc, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'updateDoc',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_deleteMany: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                match: {"in":"query","name":"match","required":true,"dataType":"string"},
                preview: {"in":"query","name":"preview","dataType":"boolean"},
        };
        app.delete('/api/docs/:type',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.deleteMany)),

            async function DocController_deleteMany(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_deleteMany, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'deleteMany',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_deleteDoc: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
        };
        app.delete('/api/docs/:type/:id',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.deleteDoc)),

            async function DocController_deleteDoc(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_deleteDoc, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'deleteDoc',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_addComment: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                args: {"in":"body","name":"args","required":true,"ref":"CommentCreate"},
        };
        app.put('/api/docs/:type/:id/comment',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.addComment)),

            async function DocController_addComment(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_addComment, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'addComment',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_getComment: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                cid: {"in":"path","name":"cid","required":true,"dataType":"string"},
        };
        app.get('/api/docs/:type/:id/comment/:cid',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.getComment)),

            async function DocController_getComment(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_getComment, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'getComment',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_updateComment: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                cid: {"in":"path","name":"cid","required":true,"dataType":"string"},
                args: {"in":"body","name":"args","required":true,"ref":"CommentUpdate"},
        };
        app.patch('/api/docs/:type/:id/comment/:cid',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.updateComment)),

            async function DocController_updateComment(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_updateComment, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'updateComment',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsDocController_deleteComment: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                cid: {"in":"path","name":"cid","required":true,"dataType":"string"},
        };
        app.delete('/api/docs/:type/:id/comment/:cid',
            ...(fetchMiddlewares<RequestHandler>(DocController)),
            ...(fetchMiddlewares<RequestHandler>(DocController.prototype.deleteComment)),

            async function DocController_deleteComment(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsDocController_deleteComment, request, response });

                const controller = new DocController();

              await templateService.apiHandler({
                methodName: 'deleteComment',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsIteratorController_getNextDoc: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                count: {"in":"query","name":"count","dataType":"double"},
        };
        app.get('/api/iterator}/:id',
            ...(fetchMiddlewares<RequestHandler>(IteratorController)),
            ...(fetchMiddlewares<RequestHandler>(IteratorController.prototype.getNextDoc)),

            async function IteratorController_getNextDoc(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsIteratorController_getNextDoc, request, response });

                const controller = new IteratorController();

              await templateService.apiHandler({
                methodName: 'getNextDoc',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
        const argsActionController_runActionForDoc: Record<string, TsoaRoute.ParameterSchema> = {
                req: {"in":"request","name":"req","required":true,"dataType":"object"},
                type: {"in":"path","name":"type","required":true,"dataType":"string"},
                id: {"in":"path","name":"id","required":true,"dataType":"string"},
                body: {"in":"body","name":"body","required":true,"dataType":"any"},
        };
        app.post('/api/action/:type/:id',
            ...(fetchMiddlewares<RequestHandler>(ActionController)),
            ...(fetchMiddlewares<RequestHandler>(ActionController.prototype.runActionForDoc)),

            async function ActionController_runActionForDoc(request: ExRequest, response: ExResponse, next: any) {

            // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

            let validatedArgs: any[] = [];
            try {
                validatedArgs = templateService.getValidatedArgs({ args: argsActionController_runActionForDoc, request, response });

                const controller = new ActionController();

              await templateService.apiHandler({
                methodName: 'runActionForDoc',
                controller,
                response,
                next,
                validatedArgs,
                successStatus: undefined,
              });
            } catch (err) {
                return next(err);
            }
        });
        // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa

    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa


    // WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
}

// WARNING: This file was auto-generated with tsoa. Please do not modify it. Re-run tsoa to re-generate this file: https://github.com/lukeautry/tsoa
